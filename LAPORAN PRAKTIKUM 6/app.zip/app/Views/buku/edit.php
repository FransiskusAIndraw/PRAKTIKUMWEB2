<!DOCTYPE html>
<html>
<head>
    <title>Edit Buku</title>
</head>
<body>
    <h1>Edit Buku</h1>
    <?php if (session()->getFlashdata('errors')): ?>
        <div>
            <?php foreach (session()->getFlashdata('errors') as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <form method="post" action="/buku/update/<?= $buku['id'] ?>">
        <label for="judul">Judul</label>
        <input type="text" name="judul" value="<?= $buku['judul'] ?>" required>
        <label for="penulis">Penulis</label>
        <input type="text" name="penulis" value="<?= $buku['penulis'] ?>" required>
        <label for="penerbit">Penerbit</label>
        <input type="text" name="penerbit" value="<?= $buku['penerbit'] ?>" required>
        <label for="tahun_terbit">Tahun Terbit</label>
        <input type="number" name="tahun_terbit" value="<?= $buku['tahun_terbit'] ?>" required>
        <button type="submit">Update</button>
    </form>
</body>
</html>
